const home = document.getElementsByClassName("home");
cont menux = document.getElementsByClassName('menu-wrap');


// const containerAll = document.getElementsByClassName('menu.wrap');
// const containerAllStyle = containerAll.style;

home.addEventListener("click", e => {
  console.log('It is working');
    // menux.style.transform : scaleX(-1);
    // function smoothScroll(event) {
event.preventDefault();
const href = this.getAttribute("href");

document.querySelector(href).scrollIntoView({
behavior: "smooth"

});

});



function smoothScroll(event) {
event.preventDefault();
const href = this.getAttribute("href");

document.querySelector(href).scrollIntoView({
behavior: "smooth"

});

}