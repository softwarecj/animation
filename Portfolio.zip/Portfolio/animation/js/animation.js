let myUrl = 'google.com';
setTimeout(function() {
  window.location.href(myUrl);
}, 3000);